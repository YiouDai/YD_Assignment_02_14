library(MASS)
m1=Boston
m1 <- round(cor(MASS::Boston, method = c("pearson")), digits = 2) 
write.csv(m1,"../Data/Raw/Boston.csv")